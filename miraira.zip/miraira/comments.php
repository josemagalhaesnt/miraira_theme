<?php
// Display comments
wp_list_comments( array(
    'callback' => 'better_comments'
) ); ?>

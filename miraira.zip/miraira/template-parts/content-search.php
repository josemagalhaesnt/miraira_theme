<div class="search-results__post">
	<article <?php post_class();?>>
		
		<?php get_post_format(); ?>

		<div class="meta-info">
	
			<span class="search-results__item">
				<h3><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
			</span>
				
		</div>

	</article>
</div>
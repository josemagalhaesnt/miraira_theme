<div <?php post_class();?>>
	<?php the_content(); ?>
</div>
